#include <stdio.h>

int main(int argc, char **argv)
{
	FILE *fp = fopen(*(argv + 1), "r");
	int i = 0, line_len = 0, line_count = 0, word_count = 0, character_count = 0;
	while(*(*(argv + 1) + i) != '.') i++;
	i++;
	
	*(*(argv + 1) + i) = 'r';
	*(*(argv + 1) + i + 1) = 'e';
	*(*(argv + 1) + i + 2) = 'v';
	
	FILE *fp_rev = fopen(*(argv + 1), "w");
	char str[251];
	char new_line;
	
	while(fscanf(fp, "%[^\n]s", str) != EOF)
	{
		line_count++;
		line_len = 0;
		i = 0;
		fscanf(fp, "%c", &new_line);
		
		while(*(str + i))
		{
			if(('a' <= *(str + i)) && (*(str + i) <= 'z'))
			{
				*(str + i) -= 32;
				word_count++;
			}
			else if('A' <= *(str + i) && *(str + i) <= 'Z')
			{
				*(str + i) += 32;
				word_count++;
			}
			if(*(str + i) != ' ') line_len++;
			i++;
		}
		fprintf(fp_rev, "%s%c", str, new_line);
		*str = 0; 
		character_count += line_len + 1; // new_line�� character�� ��� 
	}
	
	printf("Line count %d\n", line_count);
	printf("Word count %d\n", word_count);
	printf("Character count %d\n", character_count);
	printf("File Saved in %s",*(argv + 1));
	fclose(fp_rev);

	return 0;
}
